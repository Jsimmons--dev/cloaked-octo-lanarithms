#include <string>
using namespace std;
string vertiSolve(string fileLoc){
	//TODO
	return "";
}
