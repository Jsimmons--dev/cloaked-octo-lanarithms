This is the work of Corey Shannon and Josh Simmons

Project 2 - CISC320

Our project uses the test data found in the testFiles directory
and our project is tested by the Google GTest c++ testing suite.
Our assertions can be found in tests.cpp.

To run executable, type make, then ./VertiWords < testFiles/test1.txt

To run tests, type cmake CMakeLists.txt, then make, then ./runTests
